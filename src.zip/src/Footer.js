function Footer() {
  return (
    <div>
      <h1>Footer</h1>
    </div>
  );
}

export default Footer;
